
const express = require('express');
const { verifyRole } = require('./authRoutes');

const router = express.Router();

// Mock orders database
let orders = [
    { id: 1, customer_id: 2, total_price: 100, status: 'pending', invoice_issued: false },
];

// Get all orders
router.get('/orders', verifyRole('admin'), (req, res) => {
    res.json(orders);
});

// Update order status
router.put('/orders/:id', verifyRole('admin'), (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    const order = orders.find(o => o.id === parseInt(id));

    if (!order) {
        return res.status(404).json({ message: 'Order not found' });
    }

    order.status = status;
    res.json({ message: 'Order updated', order });
});

module.exports = router;
